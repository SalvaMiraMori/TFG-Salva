package com.example.tfg_salva.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tfg_salva.R
import com.example.tfg_salva.dataClasses.Game
import com.example.tfg_salva.view.NotificationsActivity

class GameCardAdapter(private val gameList: List<Game>, private val context: Context): RecyclerView.Adapter<GameCardAdapter.ViewHolder>(){

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val gameNumber: TextView = itemView.findViewById(R.id.gameNumberText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.game_card, parent, false)

        return GameCardAdapter.ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = gameList[position]

        holder.gameNumber.text = "Game " + currentItem.gameNumber.toString()

        holder.itemView.setOnClickListener(View.OnClickListener { view ->
            when (view.id) {
                R.id.gameCard -> {
                    val intent = Intent(context, NotificationsActivity::class.java)
                    intent.putExtra("Notifications", currentItem.notifications)
                    context.startActivity(intent)
                }
            }
        })
    }

    override fun getItemCount(): Int {
        return gameList.size
    }

}