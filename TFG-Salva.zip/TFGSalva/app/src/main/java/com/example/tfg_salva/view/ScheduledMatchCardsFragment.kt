package com.example.tfg_salva.view

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.tfg_salva.adapter.MatchCardAdapter
import com.example.tfg_salva.R
import com.example.tfg_salva.dataClasses.Game
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.dataClasses.Notification
import com.example.tfg_salva.dataClasses.Team
import com.example.tfg_salva.viewModel.ScheduledMatchViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [MatchCardsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ScheduledMatchCardsFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    lateinit var recyclerViewMatches: RecyclerView
    lateinit var matchesCardAdapter: MatchCardAdapter
    lateinit var scheduledMatchViewModel: ScheduledMatchViewModel
    private var TAG = "Scheduled Match Cards Fragment"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.scheduled_match_cards_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerViewMatches = requireView().findViewById(R.id.recyclerViewScheduledMatchCards)
        recyclerViewMatches.layoutManager = StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL)
        scheduledMatchViewModel = ScheduledMatchViewModel

        scheduledMatchViewModel.scheduledMatches.observe(viewLifecycleOwner, Observer {
            matchesCardAdapter = MatchCardAdapter(it, requireContext())
            recyclerViewMatches.adapter = matchesCardAdapter
        })


    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment MatchCardsFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ScheduledMatchCardsFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    private fun getScheduledMatches(){
        val db = Firebase.firestore

        db.collection("ScheduledMatches").get().addOnSuccessListener { result ->
            val matchList = ArrayList<Match>()

            for(matchDocument in result) {
                Log.d(TAG, "${matchDocument.id} => ${matchDocument.data}")
                var teamsList = ArrayList<Team>()
                var gamesList = ArrayList<Game>()
                var teamsListAux = matchDocument.data["teams"] as ArrayList<Map<String, Any>>

                var match = Match(matchDocument.data["startTime"] as String, "Unstarted",
                    matchDocument.data["esportsMatchId"] as String, gamesList, teamsList, matchDocument.data["numberOfGames"] as Int)

                for(teamAux in teamsListAux){
                    val homeLeague = teamAux["homeLeague"] as Map<String, String>
                    var teamName = teamAux["name"] as String
                    if(teamName == null){
                        teamName = "TBD"
                    }
                    teamsList += Team(teamAux["code"] as String, homeLeague["id"] as String,
                        teamAux["image"] as String, teamName, teamAux["id"] as String
                    )
                }

                match.teams = teamsList

                db.collection("CompletedMatches").document(matchDocument.id).collection("Games").get().addOnSuccessListener { result ->
                    var games = ArrayList<Game>()

                    for(gameDocument in result){
                        var notificationsList = ArrayList<Notification>()
                        var game = Game(gameDocument["esportsGameId"] as String, gameDocument["state"] as String, gameDocument["number"] as Int, notificationsList)

                        games += game
                    }

                    match.gamesList = games
                }

                Log.d(TAG, match.gamesList[0].toString())

                matchList += match
            }

            matchesCardAdapter = MatchCardAdapter(matchList, requireContext())
            recyclerViewMatches.adapter = matchesCardAdapter
        }
        .addOnFailureListener { exception ->
            Log.w(TAG, "Error getting documents.", exception)
        }
    }
}