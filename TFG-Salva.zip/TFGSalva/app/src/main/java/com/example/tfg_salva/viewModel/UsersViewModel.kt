package com.example.tfg_salva.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.dataClasses.UserData
import com.example.tfg_salva.database.DatabaseAdapter

object UsersViewModel: ViewModel(), DatabaseAdapter.UsersInterface {

    var TAG = "UsersViewModel"
    var databaseAdapter: DatabaseAdapter
    var userDataMLD: MutableLiveData<UserData>

    init {
        databaseAdapter = DatabaseAdapter()
        userDataMLD = MutableLiveData()
    }

    fun addUserIdToDB(id: String){
        databaseAdapter.addUserIdToDB(id)
    }

    override fun setUserData(userData: UserData) {
        userDataMLD.value = userData
    }

}