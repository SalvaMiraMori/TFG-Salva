package com.example.tfg_salva.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tfg_salva.R

class NotificationsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)


    }
}