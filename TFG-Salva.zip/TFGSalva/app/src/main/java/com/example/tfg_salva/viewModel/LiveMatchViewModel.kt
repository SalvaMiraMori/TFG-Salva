package com.example.tfg_salva.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tfg_salva.AppStatus
import com.example.tfg_salva.dataClasses.Game
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.dataClasses.Notification
import com.example.tfg_salva.database.DatabaseAdapter

object LiveMatchViewModel: ViewModel(), DatabaseAdapter.LiveMatchInterface {

    var liveMatches: MutableLiveData<ArrayList<Match>>
    var databaseAdapter: DatabaseAdapter

    init {
        liveMatches = MutableLiveData()
        databaseAdapter = DatabaseAdapter()
        databaseAdapter.getLiveMatches()
    }

    override fun setMatches(matches: ArrayList<Match>) {
        liveMatches.value = matches
        AppStatus.liveMatches = liveMatches.value!!
    }

    override fun setGames(esportsMatchId: String, games: ArrayList<Game>) {
        var matchList = ArrayList<Match>()
        for(match in liveMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                match.gamesList = games
            }
            matchList += match
        }

        liveMatches.value = matchList
        AppStatus.liveMatches = liveMatches.value!!
    }

    override fun setNotifications(
        esportsMatchId: String,
        esportsGameId: String,
        notifications: ArrayList<Notification>
    ) {
        var matchList = ArrayList<Match>()
        for(match in liveMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                for(game in match.gamesList){
                    if(game.esportsGameId == esportsGameId){
                        game.notifications = notifications
                    }
                }
            }
            matchList += match
        }

        liveMatches.value = matchList
        AppStatus.liveMatches = liveMatches.value!!
    }

    fun getNotificationsFromLiveMatchSync(esportsMatchId: String, esportsGameId: String){
        databaseAdapter.getNotificationsFromLiveMatchSync(esportsMatchId, esportsGameId)
    }
}