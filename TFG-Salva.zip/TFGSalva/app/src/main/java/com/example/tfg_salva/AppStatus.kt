package com.example.tfg_salva

import com.example.tfg_salva.dataClasses.Match

object AppStatus {
    lateinit var liveMatches: ArrayList<Match>
    lateinit var scheduledMatches: ArrayList<Match>
    lateinit var completedMatches: ArrayList<Match>
}