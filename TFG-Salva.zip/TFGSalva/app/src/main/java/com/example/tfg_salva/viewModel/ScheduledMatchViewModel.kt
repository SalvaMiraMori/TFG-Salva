package com.example.tfg_salva.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tfg_salva.AppStatus
import com.example.tfg_salva.dataClasses.Game
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.dataClasses.Notification
import com.example.tfg_salva.database.DatabaseAdapter

object ScheduledMatchViewModel: ViewModel(), DatabaseAdapter.ScheduledMatchInterface {

    var scheduledMatches: MutableLiveData<ArrayList<Match>>
    var databaseAdapter: DatabaseAdapter

    init {
        scheduledMatches = MutableLiveData()
        databaseAdapter = DatabaseAdapter()
        databaseAdapter.getScheduledMatches()
    }

    override fun setMatches(matches: ArrayList<Match>) {
        scheduledMatches.value = matches
        AppStatus.scheduledMatches = scheduledMatches.value!!
    }

    override fun setGames(esportsMatchId: String, games: ArrayList<Game>) {
        var matchList = ArrayList<Match>()
        for(match in scheduledMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                match.gamesList = games
            }
            matchList += match
        }

        scheduledMatches.value = matchList
        AppStatus.scheduledMatches = scheduledMatches.value!!
    }

    override fun setNotifications(
        esportsMatchId: String,
        esportsGameId: String,
        notifications: ArrayList<Notification>
    ) {
        var matchList = ArrayList<Match>()
        for(match in scheduledMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                for(game in match.gamesList){
                    if(game.esportsGameId == esportsGameId){
                        game.notifications = notifications
                    }
                }
            }
            matchList += match
        }

        scheduledMatches.value = matchList
        AppStatus.scheduledMatches = scheduledMatches.value!!
    }
}