package com.example.tfg_salva.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.example.tfg_salva.R
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.view.GamesNotificationsListActivity
import com.squareup.picasso.Picasso

class MatchCardAdapter(private val matchList: List<Match>, private val context: Context): RecyclerView.Adapter<MatchCardAdapter.ViewHolder>() {

    val TAG = "MatchCardAdapter"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.match_card, parent, false)

        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = matchList[position]

        holder.nameTeam1.text = currentItem.teams[0].name
        holder.nameTeam2.text = currentItem.teams[1].name
        holder.playingStartingTime.text = currentItem.playingStartingTime
        holder.gameNumberAndStatus.text = "Best of " + currentItem.numberOfGames
        Picasso.with(context).load(currentItem.teams[0].image).placeholder(R.mipmap.league_logo_foreground).resize(324, 324).into(holder.logoTeam1)
        // Picasso.with(context).load("https://static.lolesports.com/teams/1631819360134_rng-2021-worlds.png").placeholder(R.mipmap.league_logo_foreground).resize(324, 324).into(holder.logoTeam1)
        Log.d(TAG, "Team " + currentItem.teams[0].name + " image downloaded: " + currentItem.teams[0].image)
        Picasso.with(context).load(currentItem.teams[1].image).placeholder(R.mipmap.league_logo_foreground).resize(324, 324).into(holder.logoTeam2)
        Log.d(TAG, "Team " + currentItem.teams[1].name + " image downloaded: " + currentItem.teams[1].image)

        if(currentItem.status != "Unstarted"){
            holder.itemView.setOnClickListener(View.OnClickListener { view ->
                when (view.id) {
                    R.id.matchCard -> {
                        val intent = Intent(context, GamesNotificationsListActivity::class.java)
                        intent.putExtra("esportsMatchId", currentItem.esportsMatchId)
                        context.startActivity(intent)
                    }
                }
            })
        }
    }

    override fun getItemCount(): Int {
        return matchList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTeam1: TextView = itemView.findViewById(R.id.nameTeam1Text)
        val nameTeam2: TextView = itemView.findViewById(R.id.nameTeam2Text)
        val playingStartingTime: TextView = itemView.findViewById(R.id.playingStartingTime)
        val gameNumberAndStatus: TextView = itemView.findViewById(R.id.gameNumberAndStatusText)
        val logoTeam1: ImageView = itemView.findViewById(R.id.logoTeam1)
        val logoTeam2: ImageView = itemView.findViewById(R.id.logoTeam2)
        val vsImage: ImageView = itemView.findViewById(R.id.vsImageView)
    }

}