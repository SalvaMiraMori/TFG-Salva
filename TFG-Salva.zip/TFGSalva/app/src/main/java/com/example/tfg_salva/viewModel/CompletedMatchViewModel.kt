package com.example.tfg_salva.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tfg_salva.AppStatus
import com.example.tfg_salva.dataClasses.Game
import com.example.tfg_salva.dataClasses.Match
import com.example.tfg_salva.dataClasses.Notification
import com.example.tfg_salva.database.DatabaseAdapter

object CompletedMatchViewModel: ViewModel(), DatabaseAdapter.CompletedMatchInterface {

    var completedMatches: MutableLiveData<ArrayList<Match>>
    var databaseAdapter: DatabaseAdapter

    init {
        completedMatches = MutableLiveData()
        databaseAdapter = DatabaseAdapter()
        databaseAdapter.getCompletedMatches()
    }

    override fun setMatches(matches: ArrayList<Match>) {
        completedMatches.value = matches
        AppStatus.completedMatches = completedMatches.value!!
    }

    override fun setGames(esportsMatchId: String, games: ArrayList<Game>) {
        var matchList = ArrayList<Match>()
        for(match in completedMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                match.gamesList = games
            }
            matchList += match
        }

        completedMatches.value = matchList
        AppStatus.completedMatches = completedMatches.value!!
    }

    override fun setNotifications(
        esportsMatchId: String,
        esportsGameId: String,
        notifications: ArrayList<Notification>
    ) {
        var matchList = ArrayList<Match>()
        for(match in completedMatches.value!!){
            if(match.esportsMatchId == esportsMatchId){
                for(game in match.gamesList){
                    if(game.esportsGameId == esportsGameId){
                        game.notifications = notifications
                    }
                }
            }
            matchList += match
        }

        completedMatches.value = matchList
        AppStatus.completedMatches = completedMatches.value!!
    }
}